#version 120

uniform mat4 un_Projection;
uniform mat4 un_ModelView;

void main()
{
    gl_FragColor = vec4(0,1,0,1);
}
